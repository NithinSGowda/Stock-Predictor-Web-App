import prediction as prd
import sys
company=sys.argv[1]
prd.predict(company)